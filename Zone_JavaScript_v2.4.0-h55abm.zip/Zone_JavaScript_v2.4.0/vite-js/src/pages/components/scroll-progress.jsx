import ScrollProgressView from 'src/sections/examples/scroll-progress-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Components: Scroll Progress',
};

export default function ScrollProgressPage() {
  return <ScrollProgressView />;
}
