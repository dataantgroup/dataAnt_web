import Pricing02View from 'src/sections/pricing/view/pricing-02-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Pricing 02',
};

export default function Pricing02Page() {
  return <Pricing02View />;
}
