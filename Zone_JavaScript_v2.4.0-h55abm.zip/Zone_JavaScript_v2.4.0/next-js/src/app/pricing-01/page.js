import Pricing01View from 'src/sections/pricing/view/pricing-01-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Pricing 01',
};

export default function Pricing01Page() {
  return <Pricing01View />;
}
