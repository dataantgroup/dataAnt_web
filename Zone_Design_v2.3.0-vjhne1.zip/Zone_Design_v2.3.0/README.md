### 1.Open Figma app

### 2.Drag and Drop into app
