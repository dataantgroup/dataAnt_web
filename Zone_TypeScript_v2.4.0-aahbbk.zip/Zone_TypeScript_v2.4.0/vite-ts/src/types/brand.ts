export type IBrandProps = {
  id: string;
  name: string;
  image: string;
};
