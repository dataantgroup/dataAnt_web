// ----------------------------------------------------------------------

export type ICountriesProps = {
  code: string;
  label: string;
  phone: string;
  suggested?: boolean | undefined;
};
