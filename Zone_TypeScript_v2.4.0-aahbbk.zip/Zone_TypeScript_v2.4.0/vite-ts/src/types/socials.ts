// ----------------------------------------------------------------------

export type ISocialLinks = {
  facebook?: string;
  instagram?: string;
  linkedin?: string;
  twitter?: string;
};
