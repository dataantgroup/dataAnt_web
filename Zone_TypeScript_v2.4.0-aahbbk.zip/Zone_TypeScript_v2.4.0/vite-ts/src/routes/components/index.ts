export { default as RouterLink } from './router-link';
