// ----------------------------------------------------------------------

export type AdvertisementProps = {
  title: string;
  description: string;
  imageUrl: string;
  path: string;
};
