import ComingSoonView from 'src/sections/status/view/coming-soon-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Coming Soon',
};

export default function ComingSoonPage() {
  return <ComingSoonView />;
}
