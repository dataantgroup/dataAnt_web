import MaintenanceView from 'src/sections/status/view/maintenance-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Maintenance',
};

export default function MaintenancePage() {
  return <MaintenanceView />;
}
