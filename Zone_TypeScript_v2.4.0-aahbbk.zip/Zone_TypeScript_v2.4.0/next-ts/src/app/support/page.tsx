import SupportView from 'src/sections/support/view/support-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Support',
};

export default function SupportPage() {
  return <SupportView />;
}
