import EcommerceLandingView from 'src/sections/_ecommerce/view/ecommerce-landing-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'E-commerce: Home',
};

export default function EcommerceLandingPage() {
  return <EcommerceLandingView />;
}
